const express = require("express");
const app = express();

const port = process.env.PORT || 3000;

const style = `
  <style>
    body {
      background-color: #0f0f0f;
      color: #00ffcc;
      font-family: 'Courier New', monospace;
      text-align: center;
      padding: 40px;
    }
    a {
      color: #ff00aa;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
`;

app.get("/", (req, res) => {
  res.send(`
    ${style}
    <h1>Botumuz Aktif!</h1>
    <p>Hoşgeldin! Botumuz 7/24 açık.</p>
    <p><a href="/terms">Terms of Service</a> | <a href="/privacy">Privacy Policy</a></p>
  `);
});

app.get("/terms", (req, res) => {
  res.send(`
    ${style}
    <h1>Terms of Service</h1>
    <p>Hoşgeldin! Botumuzu kullandığın için teşekkürler.</p>
    <p>Bu botu kullanarak aşağıdaki şartları kabul etmiş olursun:</p>
    <ul>
      <li>Botu kötü amaçlarla kullanmamalısın.</li>
      <li>Sunuculara zarar vermek veya spam yapmak yasaktır.</li>
      <li>Herhangi bir yasa dışı etkinlik için kullanılamaz.</li>
      <li>Botun işleyişine müdahale etmemen beklenir.</li>
    </ul>
    <p>Şartlara uymayan kullanıcılar bot erişiminden men edilebilir.</p>
    <p>Detaylı bilgi için iletişime geçebilirsin: <a href="mailto:dayiabidd@gmail.com">dayiabidd@gmail.com</a></p>
    <p><a href="/">Ana sayfa</a></p>
  `);
});

app.get("/privacy", (req, res) => {
  res.send(`
    ${style}
    <h1>Privacy Policy</h1>
    <p>Bu bot, kullanıcıların kişisel verilerini toplamamaktadır.</p>
    <p>Kullanıcıların bilgilerinin gizliliğine önem veriyoruz.</p>
    <ul>
      <li>Toplanan veriler sadece botun çalışması için kullanılır.</li>
      <li>Veriler üçüncü şahıslarla paylaşılmaz.</li>
      <li>Herhangi bir kişisel veri saklanmaz veya analiz edilmez.</li>
    </ul>
    <p>Gizlilikle ilgili sorular için: <a href="mailto:dayiabidd@gmail.com">dayiabidd@gmail.com</a></p>
    <p><a href="/">Ana sayfa</a></p>
  `);
});

app.listen(port, () => {
  console.log(`✅ KeepAlive sunucusu çalışıyor: http://localhost:${port}`);
});
