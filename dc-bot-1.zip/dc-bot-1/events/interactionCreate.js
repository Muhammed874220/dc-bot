module.exports = {
    name: "messageReactionAdd",
    async execute(reaction, user) {
        if (user.bot) return;

        const fs = require("fs");
        const path = require("path");
        const dataPath = path.join(__dirname, "../reactionRoles.json");
        const data = JSON.parse(fs.readFileSync(dataPath));

        const guild = reaction.message.guild;
        const rrData = data.find((r) => r.messageId === reaction.message.id);
        if (!rrData) return;

        const roleData = rrData.roles.find(
            (r) => r.emoji === reaction.emoji.name,
        );
        if (roleData) {
            const member = guild.members.cache.get(user.id);
            if (member) {
                await member.roles.add(roleData.roleId);
            }
        }
    },
};
