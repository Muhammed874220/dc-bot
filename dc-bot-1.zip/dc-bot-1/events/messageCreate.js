const fs = require("fs");
const path = require("path");

const dataPath = path.join(
  __dirname,
  "..",
  "commandsPrefix",
  "otocevaplar.json",
);

let otocevaplar = {};

// Veriyi dosyadan yükleme fonksiyonu
function loadOtoCevaplar() {
  if (fs.existsSync(dataPath)) {
    try {
      otocevaplar = JSON.parse(fs.readFileSync(dataPath, "utf8"));
    } catch {
      otocevaplar = {};
    }
  }
}

module.exports = {
  name: "messageCreate",
  async execute(message) {
    if (message.author.bot) return;
    if (!message.guild) return;

    loadOtoCevaplar();

    const guildId = message.guild.id;
    if (!otocevaplar[guildId]) return;

    const content = message.content.toLowerCase();

    const found = otocevaplar[guildId].find((x) => x.trigger === content);
    if (found) {
      // Kullanıcıyı etiketleyerek cevap ver
      return message.reply({
        content: found.cevap,
        allowedMentions: { repliedUser: true },
      });
    }
  },
};
