const fs = require("fs");
const path = require("path");

const dataPath = path.join(__dirname, "../reactionRoles.json");

function loadReactionRoles() {
  if (!fs.existsSync(dataPath)) return [];
  return JSON.parse(fs.readFileSync(dataPath, "utf8"));
}

module.exports = {
  name: "messageReactionRemove",
  async execute(reaction, user) {
    if (user.bot) return;

    if (reaction.partial) await reaction.fetch();
    const data = loadReactionRoles();

    const rr = data.find(
      (d) =>
        d.guildId === reaction.message.guild.id &&
        d.messageId === reaction.message.id,
    );
    if (!rr) return;

    const roleData = rr.roles.find((r) => r.emoji === reaction.emoji.name);
    if (!roleData) return;

    const member = await reaction.message.guild.members.fetch(user.id);
    await member.roles.remove(roleData.roleId).catch(() => {});
  },
};
