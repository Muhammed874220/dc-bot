const {
  Client,
  GatewayIntentBits,
  Collection,
  REST,
  Routes,
  Partials,
} = require("discord.js");
const fs = require("fs");
const path = require("path"); // <-- bunu ekle
const chokidar = require("chokidar");
const config = require("./config.json");
require("./keepAlive.js");
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
  presence: {
    status: "dnd",
    activities: [{ name: "I LOVE ARJIN modunda!", type: 3 }],
  },
});

// Koleksiyonlar
client.commands = new Collection();
client.commandsPrefix = new Collection();
client.cooldowns = new Collection();

// Yol tanımları
const commandsPath = path.join(__dirname, "commands");
const commandsPrefixPath = path.join(__dirname, "commandsPrefix");
const eventsPath = path.join(__dirname, "events");

const rest = new REST({ version: "10" }).setToken(config.token);

// --- Slash komutları yükle ---
function loadSlashCommands() {
  client.commands.clear();
  if (!fs.existsSync(commandsPath)) return [];

  const commandFiles = fs
    .readdirSync(commandsPath)
    .filter((file) => file.endsWith(".js"));
  const commandsForAPI = [];

  for (const file of commandFiles) {
    const fullPath = path.join(commandsPath, file);
    delete require.cache[require.resolve(fullPath)];
    const command = require(fullPath);

    if ("data" in command && "execute" in command) {
      client.commands.set(command.data.name, command);
      commandsForAPI.push(command.data.toJSON());
      console.log(`[YÜKLENDİ] Slash komut: ${command.data.name}`);
    } else {
      console.warn(
        `[UYARI] Slash komut dosyasında "data" veya "execute" yok: ${file}`,
      );
    }
  }
  console.log(`[BİLGİ] Toplam slash komut: ${commandsForAPI.length}`);
  return commandsForAPI;
}

// --- Prefix komutları yükle ---
function loadPrefixCommands() {
  client.commandsPrefix.clear();
  if (!fs.existsSync(commandsPrefixPath)) return;

  const prefixFiles = fs
    .readdirSync(commandsPrefixPath)
    .filter((file) => file.endsWith(".js"));

  for (const file of prefixFiles) {
    const fullPath = path.join(commandsPrefixPath, file);
    delete require.cache[require.resolve(fullPath)];
    const command = require(fullPath);

    if ("name" in command && "execute" in command) {
      client.commandsPrefix.set(command.name, command);
      console.log(`[YÜKLENDİ] Prefix komut: ${command.name}`);
    } else {
      console.warn(
        `[UYARI] Prefix komut dosyasında "name" veya "execute" yok: ${file}`,
      );
    }
  }
}

// Diğer kodların üstüne veya uygun yere ekle:

// Promise reddedilmedi (Unhandled promise rejections) yakala
process.on("unhandledRejection", (reason, promise) => {
  console.error("🚨 Unhandled Rejection at:", promise, "reason:", reason);
  // İstersen burada botu kapatmamak için ekstra önlem alabilirsin
});

// Senkron yakalanmamış hatalar (Uncaught exceptions) yakala
process.on("uncaughtException", (error) => {
  console.error("🚨 Uncaught Exception thrown:", error);
  // İstersen burada botu kapatmamak için ekstra önlem alabilirsin
});

// Discord.js Client hataları yakala
client.on("error", (error) => {
  console.error("⚠️ Discord Client Error:", error);
});

// Shard hataları yakala (eğer shard kullanıyorsan)
client.on("shardError", (error) => {
  console.error("⚠️ Shard Error:", error);
});

// Ayrıca interactionCreate eventindeki hata yönetimini şu şekilde yapabilirsin:
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isCommand()) return;

  try {
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    await command.execute(interaction, client);
  } catch (error) {
    console.error("❌ Slash komut çalıştırılırken hata oluştu:", error);

    try {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({
          content: "❌ Bir hata oluştu.",
          ephemeral: true,
        });
      } else {
        await interaction.reply({
          content: "❌ Bir hata oluştu.",
          ephemeral: true,
        });
      }
    } catch (err) {
      console.error("⚠️ Hata mesajı gönderilirken hata:", err);
      // Burada hata mesajı da atılamazsa bot kapanmasın diye burayı boş bırakabilirsin
    }
  }
});

// --- Eventleri yükle ---
function loadEvents() {
  if (!fs.existsSync(eventsPath)) return;

  // Önce tüm event listenerları kaldır
  client.removeAllListeners();

  const eventFiles = fs
    .readdirSync(eventsPath)
    .filter((file) => file.endsWith(".js"));

  for (const file of eventFiles) {
    const fullPath = path.join(eventsPath, file);
    delete require.cache[require.resolve(fullPath)];
    const event = require(fullPath);

    if (event.once) {
      client.once(event.name, (...args) => event.execute(...args));
    } else {
      client.on(event.name, (...args) => event.execute(...args));
    }
    console.log(`[YÜKLENDİ] Event: ${event.name}`);
  }

  // Abuse eventini manuel bağla (orijinal koddan)
  client.on("guildAuditLogEntryCreate", (entry, guild) => {
    delete require.cache[require.resolve("./events/abuseEvent")];
    require("./events/abuseEvent").execute(entry, guild);
  });
}

// Slash komutları Discord API'ye yükle
async function reloadCommandsAPI(commandsForAPI) {
  try {
    console.log("🔄 Slash komutlar Discord API'ye yükleniyor...");
    await rest.put(Routes.applicationCommands(config.clientId), {
      body: commandsForAPI,
    });
    console.log(
      `✅ ${commandsForAPI.length} slash komut Discord API'ye yüklendi.`,
    );
  } catch (error) {
    console.error("❌ Slash komutları API'ye yüklenirken hata:", error);
  }
}

// --- Başlangıçta yükleme ---
(async () => {
  loadPrefixCommands();
  loadEvents();
  const commandsForAPI = loadSlashCommands();
  await reloadCommandsAPI(commandsForAPI);
})();

// --- chokidar ile dosya değişimlerini izle ve canlı reload yap ---
chokidar
  .watch(commandsPath, { ignoreInitial: true })
  .on("all", async (event, pathName) => {
    if (pathName.endsWith(".js")) {
      console.log(
        `🟡 Slash komut dosyası ${event}: ${path.basename(pathName)}`,
      );
      try {
        const commandsForAPI = loadSlashCommands();
        await reloadCommandsAPI(commandsForAPI);
      } catch (e) {
        console.error("Slash komut reload hatası:", e);
      }
    }
  });

chokidar
  .watch(commandsPrefixPath, { ignoreInitial: true })
  .on("all", (event, pathName) => {
    if (pathName.endsWith(".js")) {
      console.log(
        `🟢 Prefix komut dosyası ${event}: ${path.basename(pathName)}`,
      );
      try {
        loadPrefixCommands();
      } catch (e) {
        console.error("Prefix komut reload hatası:", e);
      }
    }
  });

chokidar
  .watch(eventsPath, { ignoreInitial: true })
  .on("all", (event, pathName) => {
    if (pathName.endsWith(".js")) {
      console.log(`🔵 Event dosyası ${event}: ${path.basename(pathName)}`);
      try {
        loadEvents();
      } catch (e) {
        console.error("Event reload hatası:", e);
      }
    }
  });

// --- Slash komutları çalıştır ---
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  const user = interaction.user;

  if (!client.cooldowns.has(command.data.name)) {
    client.cooldowns.set(command.data.name, new Collection());
  }

  const now = Date.now();
  const timestamps = client.cooldowns.get(command.data.name);
  const cooldownAmount = (command.cooldown ?? 3) * 1000;

  if (timestamps.has(user.id)) {
    const expirationTime = timestamps.get(user.id) + cooldownAmount;

    if (now < expirationTime) {
      const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
      return interaction.reply({
        content: `⏳ Lütfen **${timeLeft} saniye** bekleyip tekrar dene!`,
        ephemeral: true,
      });
    }
  }

  // Yetki ve ayar kontrolleri kaldırıldı, direkt devam ediyoruz.

  timestamps.set(user.id, now);
  setTimeout(() => timestamps.delete(user.id), cooldownAmount);

  try {
    await command.execute(interaction, client);
  } catch (error) {
    console.error("❌ Slash komut çalıştırılırken hata oluştu:", error);
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({
        content: "❌ Bir hata oluştu.",
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        content: "❌ Bir hata oluştu.",
        ephemeral: true,
      });
    }
  }
});

// --- Prefix komutları çalıştır ---
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.guild) return;
  if (!message.content.startsWith("o+")) return;

  const args = message.content.slice(2).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  const command = client.commandsPrefix.get(commandName);
  if (!command) return;

  // Rol kontrolü kaldırıldı, direkt devam ediyoruz.

  try {
    await command.execute(message, args, client);
  } catch (error) {
    console.error("❌ Prefix komut çalıştırılırken hata:", error);
    message.reply("❌ Komut çalıştırılırken hata oluştu.");
  }
});

// --- Abuse eventini manuel bağla ---
client.on("guildAuditLogEntryCreate", (entry, guild) => {
  delete require.cache[require.resolve("./events/abuseEvent")];
  require("./events/abuseEvent").execute(entry, guild);
});

// ------------- BURAYA REACTION ROL EVENTLERİNİ EKLİYORUZ ---------------

client.on("messageReactionAdd", async (reaction, user) => {
  if (user.bot) return;

  // Eğer reaction partial ise fetch et
  if (reaction.partial) await reaction.fetch();
  if (reaction.message.partial) await reaction.message.fetch();

  // Burada reaction rol verilerini tutan yapıyı kendi koduna göre ayarla
  // Ben örnek olarak global.reactionRoles Map'i kullandım
  // reactionRoles = Map<messageId, {emojiName veya emojiId: roleId}>
  const reactionRoles = global.reactionRoles;
  if (!reactionRoles) return;

  const rolMap = reactionRoles.get(reaction.message.id);
  if (!rolMap) return;

  // Emoji identifier veya name ile roleId'yi al
  const roleId =
    rolMap[reaction.emoji.identifier] || rolMap[reaction.emoji.name];
  if (!roleId) return;

  const member = reaction.message.guild.members.cache.get(user.id);
  if (!member) return;

  try {
    await member.roles.add(roleId);
    console.log(`${user.tag} kullanıcısına rol verildi.`);
  } catch (err) {
    console.error("Rol verilirken hata:", err);
  }
});

client.on("messageReactionRemove", async (reaction, user) => {
  if (user.bot) return;

  if (reaction.partial) await reaction.fetch();
  if (reaction.message.partial) await reaction.message.fetch();

  const reactionRoles = global.reactionRoles;
  if (!reactionRoles) return;

  const rolMap = reactionRoles.get(reaction.message.id);
  if (!rolMap) return;

  const roleId =
    rolMap[reaction.emoji.identifier] || rolMap[reaction.emoji.name];
  if (!roleId) return;

  const member = reaction.message.guild.members.cache.get(user.id);
  if (!member) return;

  try {
    await member.roles.remove(roleId);
    console.log(`${user.tag} kullanıcısından rol alındı.`);
  } catch (err) {
    console.error("Rol alınırken hata:", err);
  }
});

// ------------------------------------------------------------------------

client.once("ready", () => {
  console.log(`🤖 ${client.user.tag} olarak giriş yapıldı.`);
  console.log(`📦 Slash komut sayısı: ${client.commands.size}`);
  console.log(`📦 Prefix komut sayısı: ${client.commandsPrefix.size}`);
});

client.login(config.token);
