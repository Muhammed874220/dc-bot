const fs = require("fs");
const path = require("path");

const dataPath = path.join(__dirname, "otocevaplar.json");

let otocevaplar = {};

// Dosyadan yükle
function loadOtoCevaplar() {
  if (fs.existsSync(dataPath)) {
    try {
      otocevaplar = JSON.parse(fs.readFileSync(dataPath, "utf8"));
    } catch {
      otocevaplar = {};
    }
  }
}

// Dosyaya kaydet
function saveOtoCevaplar() {
  fs.writeFileSync(dataPath, JSON.stringify(otocevaplar, null, 2));
}

loadOtoCevaplar();

module.exports = {
  name: "otocevap",
  description: "Otomatik cevap sistemini yönetir (admin komutu)",

  async execute(message, args) {
    if (!message.guild)
      return message.channel.send("❌ Bu komut sadece sunucularda çalışır.");
    if (!message.member.permissions.has("ADMINISTRATOR"))
      return message.channel.send(
        "❌ Bu komutu sadece sunucu yöneticileri kullanabilir.",
      );

    const guildId = message.guild.id;
    if (!otocevaplar[guildId]) otocevaplar[guildId] = [];

    if (!args.length) {
      if (otocevaplar[guildId].length === 0) {
        return message.channel.send("Bu sunucuda kayıtlı otomatik cevap yok.");
      }
      const liste = otocevaplar[guildId]
        .map((x, i) => `${i + 1}. **${x.trigger}** → ${x.cevap}`)
        .join("\n");
      return message.channel.send(`Sunucudaki otomatik cevaplar:\n${liste}`);
    }

    // Komut formatı: !otocevap tetikleyici | cevap mesajı
    const joined = args.join(" ");
    if (!joined.includes("|")) {
      return message.channel.send(
        "Yanlış kullanım! Doğru format:\n`!otocevap tetikleyici | cevap mesajı`",
      );
    }

    const [triggerRaw, ...cevapArr] = joined.split("|");
    const trigger = triggerRaw.trim().toLowerCase();
    const cevap = cevapArr.join("|").trim();

    if (otocevaplar[guildId].length >= 5) {
      return message.channel.send("En fazla 5 otomatik cevap ekleyebilirsin.");
    }

    if (otocevaplar[guildId].some((x) => x.trigger === trigger)) {
      return message.channel.send("Bu tetikleyici zaten mevcut.");
    }

    otocevaplar[guildId].push({ trigger, cevap });
    saveOtoCevaplar();

    return message.channel.send(
      `✅ Otomatik cevap eklendi:\n**${trigger}** → ${cevap}`,
    );
  },
};
