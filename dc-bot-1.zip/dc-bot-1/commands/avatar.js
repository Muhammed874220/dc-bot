const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("avatar")
    .setDescription("Bir kullanıcının avatarını gösterir.")
    .addUserOption((option) =>
      option
        .setName("kişi")
        .setDescription("Avatarını görmek istediğin kişi")
        .setRequired(false),
    ),

  async execute(interaction) {
    const user = interaction.options.getUser("kişi") || interaction.user;

    if (user.id === "1179873613885751300") {
      return interaction.reply({
        content: "Bu kullanıcının avatarını görüntüleyemezsiniz.",
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor("Random")
      .setTitle(`🖼 ${user.username} Avatarı`)
      .setImage(user.displayAvatarURL({ dynamic: true, size: 4096 }))
      .setFooter({ text: `ID: ${user.id}` });

    await interaction.reply({ embeds: [embed] });
  },
};
