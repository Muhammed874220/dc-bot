const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("ping")
        .setDescription(
            "Botun tepki süresini ve gecikme bilgilerini gösterir.",
        ),

    async execute(interaction) {
        const sent = await interaction.reply({
            content: "📡 Ping ölçülüyor...",
            fetchReply: true,
        });

        const ping = sent.createdTimestamp - interaction.createdTimestamp;
        const apiLatency = Math.round(interaction.client.ws.ping);

        const embed = new EmbedBuilder()
            .setColor(0xff0060)
            .setTitle("🏓 Ping Durumu")
            .addFields(
                {
                    name: "📨 Mesaj Gecikmesi",
                    value: `\`${ping}ms\``,
                    inline: true,
                },
                {
                    name: "🌐 API Gecikmesi",
                    value: `\`${apiLatency}ms\``,
                    inline: true,
                },
            )
            .setFooter({
                text: `${interaction.client.user.username} • Discord.js v14`,
                iconURL: interaction.client.user.displayAvatarURL(),
            })
            .setTimestamp();

        await interaction.editReply({ content: null, embeds: [embed] });
    },
};
