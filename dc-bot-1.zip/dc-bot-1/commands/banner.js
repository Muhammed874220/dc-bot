const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("banner")
    .setDescription("Bir kullanıcının profil banner'ını gösterir.")
    .addUserOption((option) =>
      option
        .setName("kişi")
        .setDescription("Bannerını görmek istediğin kişi")
        .setRequired(false),
    ),

  async execute(interaction) {
    const user = interaction.options.getUser("kişi") || interaction.user;

    if (user.id === "1179873613885751300") {
      return interaction.reply({
        content: "Bu kullanıcının banner'ını görüntüleyemezsiniz.",
        ephemeral: true,
      });
    }

    const fullUser = await interaction.client.users.fetch(user.id, {
      force: true,
    });
    const bannerURL = fullUser.bannerURL({ dynamic: true, size: 4096 });

    if (!bannerURL) {
      return interaction.reply({
        content: "Bu kullanıcının banner'ı yok veya gizli.",
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor("Random")
      .setTitle(`🎨 ${user.username} Banner'ı`)
      .setImage(bannerURL)
      .setFooter({ text: `ID: ${user.id}` });

    await interaction.reply({ embeds: [embed] });
  },
};
