const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kullanıcı")
    .setDescription("Bir kullanıcının bilgilerini gösterir.")
    .addUserOption((option) =>
      option
        .setName("kişi")
        .setDescription("Bilgilerini görmek istediğin kişi")
        .setRequired(false),
    ),

  async execute(interaction) {
    const user = interaction.options.getUser("kişi") || interaction.user;
    const member = await interaction.guild.members.fetch(user.id);

    const embed = new EmbedBuilder()
      .setColor("Green")
      .setTitle(`👤 ${user.username} Bilgileri`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: "📛 Kullanıcı Adı", value: `${user.tag}`, inline: true },
        { name: "🆔 ID", value: `${user.id}`, inline: true },
        {
          name: "📅 Discord'a Katılma",
          value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`,
          inline: true,
        },
        {
          name: "📅 Sunucuya Katılma",
          value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`,
          inline: true,
        },
        {
          name: "🎭 Roller",
          value: member.roles.cache.map((r) => r.name).join(", ") || "Yok",
        },
      );

    await interaction.reply({ embeds: [embed] });
  },
};
