const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dataPath = path.join(__dirname, "../reactionRoles.json");

// JSON okuma
function loadReactionRoles() {
  if (!fs.existsSync(dataPath)) return [];
  return JSON.parse(fs.readFileSync(dataPath, "utf8"));
}

// JSON kaydetme
function saveReactionRoles(data) {
  fs.writeFileSync(dataPath, JSON.stringify(data, null, 2), "utf8");
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("emojirol")
    .setDescription("Emojiye tıklayınca rol verme sistemi kurar.")
    .addChannelOption((opt) =>
      opt
        .setName("kanal")
        .setDescription("Mesajın gönderileceği kanal")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt.setName("baslik").setDescription("Embed başlığı").setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName("icerik")
        .setDescription("Embed açıklaması")
        .setRequired(true),
    )
    // Rol + emoji seçenekleri
    .addRoleOption((opt) => opt.setName("rol1").setDescription("1. rol"))
    .addStringOption((opt) =>
      opt.setName("rol1emoji").setDescription("1. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol2").setDescription("2. rol"))
    .addStringOption((opt) =>
      opt.setName("rol2emoji").setDescription("2. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol3").setDescription("3. rol"))
    .addStringOption((opt) =>
      opt.setName("rol3emoji").setDescription("3. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol4").setDescription("4. rol"))
    .addStringOption((opt) =>
      opt.setName("rol4emoji").setDescription("4. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol5").setDescription("5. rol"))
    .addStringOption((opt) =>
      opt.setName("rol5emoji").setDescription("5. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol6").setDescription("6. rol"))
    .addStringOption((opt) =>
      opt.setName("rol6emoji").setDescription("6. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol7").setDescription("7. rol"))
    .addStringOption((opt) =>
      opt.setName("rol7emoji").setDescription("7. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol8").setDescription("8. rol"))
    .addStringOption((opt) =>
      opt.setName("rol8emoji").setDescription("8. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol9").setDescription("9. rol"))
    .addStringOption((opt) =>
      opt.setName("rol9emoji").setDescription("9. rol emojisi"),
    )
    .addRoleOption((opt) => opt.setName("rol10").setDescription("10. rol"))
    .addStringOption((opt) =>
      opt.setName("rol10emoji").setDescription("10. rol emojisi"),
    ),

  async execute(interaction) {
    const channel = interaction.options.getChannel("kanal");
    const title = interaction.options.getString("baslik");
    const description = interaction.options.getString("icerik");

    let roles = [];
    for (let i = 1; i <= 10; i++) {
      let role = interaction.options.getRole(`rol${i}`);
      let emoji = interaction.options.getString(`rol${i}emoji`);
      if (role && emoji) roles.push({ roleId: role.id, emoji });
    }

    if (roles.length === 0) {
      return interaction.reply({
        content: "En az 1 rol ve emoji girmelisin!",
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(
        description +
          "\n\n" +
          roles.map((r) => `${r.emoji} <@&${r.roleId}>`).join("\n"),
      )
      .setColor("Random");

    const message = await channel.send({ embeds: [embed] });

    for (const r of roles) {
      await message.react(r.emoji);
    }

    // JSON’a kaydet
    const data = loadReactionRoles();
    data.push({
      guildId: interaction.guild.id,
      channelId: channel.id,
      messageId: message.id,
      roles,
    });
    saveReactionRoles(data);

    await interaction.reply({
      content: "✅ Emoji rol sistemi kuruldu!",
      ephemeral: true,
    });
  },
};
