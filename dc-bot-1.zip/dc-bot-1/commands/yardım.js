const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("yardım")
    .setDescription("Tüm komutları listeler."),

  async execute(interaction) {
    // 📂 Slash komutlarını oku
    const slashPath = path.join(__dirname, ".");
    const slashFiles = fs
      .readdirSync(slashPath)
      .filter((file) => file.endsWith(".js"));

    const slashListesi = slashFiles.map((file) => {
      const command = require(path.join(slashPath, file));
      return `\`/${command.data.name}\` - ${command.data.description}`;
    });

    // 📂 Prefix komutlarını oku
    const prefixPath = path.join(__dirname, "../commandsPrefix");
    let prefixListesi = [];

    if (fs.existsSync(prefixPath)) {
      const prefixFiles = fs
        .readdirSync(prefixPath)
        .filter((file) => file.endsWith(".js"));
      prefixListesi = prefixFiles.map((file) => {
        const command = require(path.join(prefixPath, file));
        // Prefix komut dosyalarında name ve description varsa ekle
        return `\`${command.name}\` - ${command.description || "Açıklama yok"}`;
      });
    }

    // 📜 Embed hazırla
    const embed = new EmbedBuilder()
      .setColor("Blurple")
      .setTitle("📜 Yardım Menüsü")
      .addFields(
        { name: "💠 Slash Komutlar", value: slashListesi.join("\n") || "Yok" },
        {
          name: "📦 Prefix Komutlar",
          value: prefixListesi.join("\n") || "Yok",
        },
      )
      .setFooter({
        text: `Toplam ${slashListesi.length + prefixListesi.length} komut var.`,
      });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
