const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const axios = require("axios");
const moment = require("moment");
require("moment-duration-format");
require("moment/locale/tr");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("üyeprofil")
    .setDescription("Bir Roblox kullanıcısının bilgilerini gösterir.")
    .addStringOption((option) =>
      option
        .setName("kullanici")
        .setDescription("Kullanıcı adını gir.")
        .setRequired(true),
    ),

  async execute(interaction) {
    const username = interaction.options.getString("kullanici");

    await interaction.deferReply(); // uzun sürede yanıt verirse beklet

    try {
      // ✅ Yeni roblox API ile kullanıcı bilgisi alma
      const response = await axios.post(
        "https://users.roblox.com/v1/usernames/users",
        {
          usernames: [username],
          excludeBannedUsers: false,
        },
      );

      const user = response.data.data[0];
      if (!user) {
        return interaction.editReply("❌ Bu kullanıcı bulunamadı.");
      }

      // Kullanıcı bilgilerini çek
      const infoRes = await axios.get(
        `https://users.roblox.com/v1/users/${user.id}`,
      );

      const createdDate = moment(infoRes.data.created);
      const now = moment();
      const accountAgeDays = now.diff(createdDate, "days");

      const embed = new EmbedBuilder()
        .setTitle("👤 Roblox Kullanıcı Bilgisi")
        .setColor("Random")
        .setThumbnail(
          `https://www.roblox.com/headshot-thumbnail/image?userId=${user.id}&width=420&height=420&format=png`,
        )
        .addFields(
          { name: "Kullanıcı Adı", value: user.name, inline: true },
          {
            name: "Display Name",
            value: user.displayName || "Yok",
            inline: true,
          },
          { name: "Kullanıcı ID", value: `${user.id}`, inline: true },
          { name: "Hesap Yaşı", value: `${accountAgeDays} gün`, inline: true },
          {
            name: "Kuruluş Tarihi",
            value: createdDate.locale("tr").format("LLL"),
            inline: true,
          },
        )
        .setFooter({
          text: `İsteyen: ${interaction.user.tag}`,
          iconURL: interaction.user.displayAvatarURL(),
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      await interaction.editReply(
        "❌ Kullanıcı bilgileri alınırken bir hata oluştu.",
      );
    }
  },
};
