const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  PermissionsBitField,
} = require("discord.js");
const noblox = require("noblox.js");
const fs = require("fs");
require("dotenv").config();

const config = require("../config.json");

const channelFile = "./channelData.json";
const groupId = 322875371;

module.exports = {
  data: new SlashCommandBuilder()
    .setName("rütbe-güncelle")
    .setDescription("Kullanıcıyı Roblox grubunda bir role atar (onaylı).")
    .addStringOption((option) =>
      option
        .setName("username")
        .setDescription("Roblox kullanıcı adı")
        .setRequired(true),
    ),

  async execute(interaction) {
    const username = interaction.options.getString("username");
    const userCookie = process.env.ROBLOX_COOKIE;

    if (
      !interaction.member.permissions.has(
        PermissionsBitField.Flags.Administrator,
      )
    ) {
      return interaction.reply({
        content: "❌ Bu komutu kullanmak için **yönetici** olman gerek!",
        ephemeral: true,
      });
    }

    if (!userCookie) {
      return interaction.reply({
        content: "HATA: .env dosyasında ROBLOX_COOKIE tanımlı değil.",
        ephemeral: true,
      });
    }

    const channelId =
      process.env.APPROVAL_CHANNEL_ID || config.approvalChannelId;
    const approvalChannel = interaction.client.channels.cache.get(channelId);

    if (!approvalChannel) {
      return interaction.reply({
        content: "Onay kanalı bulunamadı.",
        ephemeral: true,
      });
    }

    try {
      await noblox.setCookie(userCookie);
      const userRobloxId = await noblox.getIdFromUsername(username);
      const currentRank = await noblox.getRankInGroup(groupId, userRobloxId);
      const roles = await noblox.getRoles(groupId);

      const seenRanks = new Set();
      const roleOptions = roles
        .filter((r) => r.rank > 0 && r.rank <= 254 && r.rank !== currentRank)
        .filter((r) => {
          if (seenRanks.has(r.rank)) return false;
          seenRanks.add(r.rank);
          return true;
        })
        .map((role) => ({
          label: `${role.name} (Rank: ${role.rank})`,
          value: `${role.rank}-${role.name}`,
        }));

      if (roleOptions.length === 0) {
        return interaction.reply({
          content: "Bu kullanıcıya atanabilecek başka rütbe bulunamadı.",
          ephemeral: true,
        });
      }

      const embed = new EmbedBuilder()
        .setColor("#000000")
        .setTitle("Rütbe Seçimi")
        .setDescription(`**${username}** için atanacak rütbeyi seç:`);

      const menus = [];
      const chunkSize = 25;

      for (let i = 0; i < roleOptions.length; i += chunkSize) {
        const chunk = roleOptions.slice(i, i + chunkSize);
        const menu = new StringSelectMenuBuilder()
          .setCustomId(`rank_select_${i / chunkSize}`)
          .setPlaceholder(`Sayfa ${i / chunkSize + 1}`)
          .addOptions(chunk);

        menus.push(new ActionRowBuilder().addComponents(menu));
      }

      await interaction.reply({ embeds: [embed], components: menus });

      const filter = (i) =>
        i.user.id === interaction.user.id &&
        i.customId.startsWith("rank_select");

      const collector = interaction.channel.createMessageComponentCollector({
        filter,
        time: 60000,
      });

      collector.on("collect", async (i) => {
        const selectedValue = i.values[0];
        const selectedRank = parseInt(selectedValue.split("-")[0]);
        const selectedRole = roles.find((r) => r.rank === selectedRank);

        const confirmEmbed = new EmbedBuilder()
          .setColor("Orange")
          .setTitle("✅ Rütbe Onayı Bekleniyor")
          .setDescription(
            `**${username}** için \`${selectedRole.name}\` rütbesi atanmak isteniyor.`,
          )
          .addFields(
            { name: "🧑 Kullanıcı", value: `\`${username}\``, inline: true },
            {
              name: "🏅 Hedef Rütbe",
              value: `**${selectedRole.name}**`,
              inline: true,
            },
            {
              name: "👤 Talep Eden",
              value: `<@${interaction.user.id}>`,
              inline: true,
            },
          );

        const sendConfirm = async (targetChannel) => {
          const message = await targetChannel.send({
            embeds: [confirmEmbed],
          });

          await message.react("✅");
          await message.react("❌");

          const reactionFilter = (reaction, user) => {
            return (
              ["✅", "❌"].includes(reaction.emoji.name) &&
              !user.bot &&
              user.id === interaction.user.id
            );
          };

          const reactionCollector = message.createReactionCollector({
            filter: reactionFilter,
            max: 1,
            time: 60000,
          });

          reactionCollector.on("collect", async (reaction) => {
            if (reaction.emoji.name === "✅") {
              try {
                await noblox.setRank(groupId, userRobloxId, selectedRank);
                await message.reply({
                  content: `✅ **${username}** adlı kullanıcıya **${selectedRole.name}** rütbesi başarıyla atandı.`,
                });
              } catch (err) {
                await message.reply({
                  content: `❌ Rütbe atanırken hata oluştu: ${err.message}`,
                });
              }
            } else if (reaction.emoji.name === "❌") {
              await message.reply({
                content: `❌ Rütbe ataması iptal edildi.`,
              });
            }
          });
        };

        // Onay kanalına gönder
        await sendConfirm(approvalChannel);

        // Ek kanal varsa oraya da gönder
        if (fs.existsSync(channelFile)) {
          const channelData = JSON.parse(fs.readFileSync(channelFile, "utf8"));
          const extraChannel = interaction.guild.channels.cache.get(
            channelData.channelId,
          );
          if (extraChannel) {
            await sendConfirm(extraChannel);
          }
        }

        await i.update({
          content: `✅ Rütbe isteği gönderildi, onay için emoji bekleniyor.`,
          components: [],
        });

        collector.stop();
      });
    } catch (error) {
      console.error(error);
      await interaction.reply({
        content: `Bir hata oluştu: ${error.message}`,
        ephemeral: true,
      });
    }
  },
};
