const {
  SlashCommandBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  EmbedBuilder,
} = require("discord.js");
const axios = require("axios");
const HttpsProxyAgent = require("https-proxy-agent");

// Proxy listesi - gerçek proxy adreslerinle değiştir!
const proxyList = [
  "http://ip1:port1",
  "http://ip2:port2",
  // ... proxy ekle
];

let proxyIndex = 0;

async function axiosWithProxyRetry(
  url,
  options = {},
  retries = proxyList.length,
) {
  for (let i = 0; i < retries; i++) {
    try {
      const agent = new HttpsProxyAgent(proxyList[proxyIndex]);
      proxyIndex = (proxyIndex + 1) % proxyList.length;

      return await axios.get(url, {
        ...options,
        httpsAgent: agent,
        proxy: false,
      });
    } catch (error) {
      if (error.response && error.response.status === 429) {
        console.log(
          `Rate limit aldık, proxy değiştiriliyor... (${proxyIndex})`,
        );
        continue; // diğer proxy ile tekrar dene
      }
      throw error; // 429 değilse fırlat
    }
  }
  throw new Error("Tüm proxylerde rate limit hatası alındı.");
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName("üyesorgu")
    .setDescription(
      "Bir kullanıcının Roblox'taki tüm gruplarını sıralar ve üye sayılarını gösterir.",
    )
    .addStringOption((option) =>
      option
        .setName("username")
        .setDescription("Roblox kullanıcı adını girin")
        .setRequired(true),
    ),

  async execute(interaction) {
    const username = interaction.options.getString("username");

    try {
      // Roblox kullanıcı bilgilerini proxy destekli al
      const userResponse = await axiosWithProxyRetry(
        `https://users.roblox.com/v1/users/search?keyword=${username}`,
      );
      const userData = userResponse.data;

      if (userData.data.length === 0) {
        return await interaction.reply({
          content: `❌ Kullanıcı "${username}" bulunamadı.`,
          ephemeral: true,
        });
      }

      const userId = userData.data[0].id;

      // Kullanıcının gruplarını proxy destekli al
      const groupsResponse = await axiosWithProxyRetry(
        `https://groups.roblox.com/v1/users/${userId}/groups/roles`,
      );
      const groupsData = groupsResponse.data;

      if (groupsData.data.length === 0) {
        return await interaction.reply({
          content: `❌ Kullanıcı "${username}" hiçbir gruba üye değil.`,
          ephemeral: true,
        });
      }

      // Üye sayıları için her grup için proxy destekli istek
      const groupsWithMemberCounts = await Promise.all(
        groupsData.data.map(async (group) => {
          try {
            const groupInfo = await axiosWithProxyRetry(
              `https://groups.roblox.com/v1/groups/${group.group.id}`,
            );
            return {
              name: group.group.name,
              role: group.role.name,
              memberCount: groupInfo.data.memberCount || "Bilinmiyor",
            };
          } catch {
            return {
              name: group.group.name,
              role: group.role.name,
              memberCount: "Bilinmiyor",
            };
          }
        }),
      );

      const pageSize = 10;
      let currentPage = 0;
      const totalPages = Math.ceil(groupsWithMemberCounts.length / pageSize);

      const generateEmbed = (page) => {
        const start = page * pageSize;
        const end = start + pageSize;
        const pageGroups = groupsWithMemberCounts.slice(start, end);

        const embed = new EmbedBuilder()
          .setTitle(`${username} - Üye Olduğu Gruplar`)
          .setDescription(
            pageGroups
              .map(
                (g) =>
                  `**${g.name}**\n🏅 Rütbe: ${g.role}\n👤 Toplam Üye: ${g.memberCount}`,
              )
              .join("\n\n"),
          )
          .setFooter({ text: `Sayfa ${page + 1}/${totalPages}` })
          .setColor(0x0099ff);

        return embed;
      };

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("previous")
          .setLabel("⬅ Geri")
          .setStyle(ButtonStyle.Primary)
          .setDisabled(currentPage === 0),
        new ButtonBuilder()
          .setCustomId("next")
          .setLabel("İleri ➡")
          .setStyle(ButtonStyle.Primary)
          .setDisabled(currentPage + 1 >= totalPages),
      );

      // interaction.reply'yi try/catch içinde ve takipli yap
      let message;
      try {
        message = await interaction.reply({
          embeds: [generateEmbed(currentPage)],
          components: [row],
          fetchReply: true,
        });
      } catch (err) {
        console.error("Reply hatası, followUp ile dene:", err);
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({
            content: "❌ Bir hata oluştu (reply sırasında).",
            ephemeral: true,
          });
        } else {
          await interaction.followUp({
            content: "❌ Bir hata oluştu (followUp).",
            ephemeral: true,
          });
        }
        return;
      }

      const collector = message.createMessageComponentCollector({
        time: 60000,
      });

      collector.on("collect", async (buttonInteraction) => {
        if (buttonInteraction.user.id !== interaction.user.id) {
          return await buttonInteraction.reply({
            content: "Bu butonları sadece komutu kullanan kişi kullanabilir!",
            ephemeral: true,
          });
        }

        if (buttonInteraction.customId === "previous" && currentPage > 0) {
          currentPage--;
        } else if (
          buttonInteraction.customId === "next" &&
          currentPage + 1 < totalPages
        ) {
          currentPage++;
        }

        const newRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("previous")
            .setLabel("⬅ Geri")
            .setStyle(ButtonStyle.Primary)
            .setDisabled(currentPage === 0),
          new ButtonBuilder()
            .setCustomId("next")
            .setLabel("İleri ➡")
            .setStyle(ButtonStyle.Primary)
            .setDisabled(currentPage + 1 >= totalPages),
        );

        try {
          await buttonInteraction.update({
            embeds: [generateEmbed(currentPage)],
            components: [newRow],
          });
        } catch (err) {
          console.error("Button update hatası:", err);
          if (!buttonInteraction.replied && !buttonInteraction.deferred) {
            await buttonInteraction.reply({
              content: "❌ Bir hata oluştu (buton işlemi).",
              ephemeral: true,
            });
          } else {
            await buttonInteraction.followUp({
              content: "❌ Bir hata oluştu (buton followUp).",
              ephemeral: true,
            });
          }
        }
      });

      collector.on("end", () => {
        message.edit({ components: [] }).catch(() => {});
      });
    } catch (error) {
      console.error("Genel catch hatası:", error);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: "❌ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.",
          ephemeral: true,
        });
      } else {
        await interaction.followUp({
          content: "❌ Bir hata oluştu. Lütfen daha sonra tekrar deneyin.",
          ephemeral: true,
        });
      }
    }
  },
};
